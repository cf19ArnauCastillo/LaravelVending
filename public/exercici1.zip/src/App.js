import {useState} from 'react'
import './App.css'
import homer from './img/homer.png'

function App() {
  
  const [h2_text, set_h2_text] = useState("Init value")

  const onChange1 = (e) => {
    set_h2_text(e.target.value)
  }
  
  const onClick1 = (e) => {
    e.target.style.backgroundColor = "blue"
    e.target.style.color = "white"
  }
  return (
    <div className="App">
      <img className="App-logo" src={homer} alt="homer" />
      <h1>Hello World</h1>
      <h2>{h2_text}</h2>
      <input type="text" onChange={onChange1}/>
      <button onClick={onClick1}>Click on me !!</button>
    </div>
  );
}

export default App;
